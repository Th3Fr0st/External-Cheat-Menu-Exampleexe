# External-Cheat-Menu-Example

[![C++](https://img.shields.io/badge/Language-C%2B%2B-%23f34b7d.svg?style=flat)](https://en.wikipedia.org/wiki/C%2B%2B) 
[![Windows](https://img.shields.io/badge/Platform-Windows-0078d7.svg?style=flat)](https://en.wikipedia.org/wiki/Microsoft_Windows) 
[![x64](https://img.shields.io/badge/Arch-x64-green.svg?style=flat)](https://en.wikipedia.org/wiki/X64) 

> This is a ready-to-use external cheat menu and it does not have any game hook functions. 

## Disclaimer
[This program](https://github.com/NotSlater/External-Cheat-Menu-Example) is for educational purposes only!

Copyright Disclaimer under section 107 of the Copyright Act 1976, allowance is made for “fair use” for purposes such as criticism, comment, news reporting, teaching, scholarship, education and research.

## Features
(These are just features without functions)  
*   **Aimbot**
*   **Smoothing**
*   **Fov Circle** (Working but Fix background and make it transparent)
*   **Visible Check**
*   **Team Check**  
*   **Custom Overlay (Semi-Working, Need Make Background Transparent)**  
*   **Visuals**
*   **Full Box**
*   **Corner Box**
*   **Skeletonx**
*   **Name**
*   **Health**
*   **Weapon**
*   **Extras**
*   **No Recoil**
*   **No Spread**

## **How To Use**  
Requirements: Visual Studio
(You can add a font to make it look better)
```
Step 1: Download all files and extract to a folder
Step 2: Run ExternalMenu.vcxproj
Step 3: Set Solution Config to Release
Step 4: Go to Project->Properties
Step 5: Change C++ Lang Standard to C++17
```
Preview of base menu  
![image](https://user-images.githubusercontent.com/59234115/155837314-3ffd5ffb-5f59-4a30-82da-fb0af1a64021.png)
